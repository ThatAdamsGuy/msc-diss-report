using System.Globalization;
using System.Text.Json;
using UndercutAnalyser.Infrastructure;

namespace UndercutAnalyser.Tests;

public sealed class DateTimeNullableJsonConverterTests
{
    #region Read token handling and parse resilience
    // These tests exist to lock down accepted token forms and null-on-failure behavior,
    // preventing API data quirks from throwing at deserialization boundaries.

    [Fact]
    public void Read_NullToken_ReturnsNull()
    {
        var result = DeserializeDate("{" + "\"value\":null" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_IsoString_ReturnsParsedDateTime()
    {
        var result = DeserializeDate("{" + "\"value\":\"2025-01-02T03:04:05Z\"" + "}");

        Assert.NotNull(result);
        Assert.Equal(new DateTime(2025, 1, 2, 3, 4, 5, DateTimeKind.Utc), result.Value.ToUniversalTime());
    }

    [Fact]
    public void Read_CommonDateFormat_ReturnsParsedDateTime()
    {
        var result = DeserializeDate("{" + "\"value\":\"2025-01-02\"" + "}");

        Assert.NotNull(result);
    }

    [Fact]
    public void Read_InvalidString_ReturnsNull()
    {
        var result = DeserializeDate("{" + "\"value\":\"not-a-date\"" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_UnixEpochSeconds_ReturnsUtcDateTime()
    {
        var result = DeserializeDate("{" + "\"value\":1700000000" + "}");

        Assert.NotNull(result);
        Assert.Equal(DateTimeKind.Utc, result.Value.Kind);
        Assert.Equal(DateTimeOffset.FromUnixTimeSeconds(1700000000).UtcDateTime, result.Value);
    }

    [Fact]
    public void Read_UnixEpochMilliseconds_ReturnsUtcDateTime()
    {
        var result = DeserializeDate("{" + "\"value\":1700000000000" + "}");

        Assert.NotNull(result);
        Assert.Equal(DateTimeKind.Utc, result.Value.Kind);
        Assert.Equal(DateTimeOffset.FromUnixTimeMilliseconds(1700000000000).UtcDateTime, result.Value);
    }

    [Fact]
    public void Read_UnsupportedTokenType_ReturnsNull()
    {
        var result = DeserializeDate("{" + "\"value\":true" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_WhitespaceString_ReturnsNull()
    {
        var result = DeserializeDate("{" + "\"value\":\"   \"" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_CommonDateTimeFormat_ReturnsParsedDateTime()
    {
        var result = DeserializeDate("{" + "\"value\":\"2025-01-02 03:04:05\"" + "}");

        Assert.NotNull(result);
        Assert.Equal(2025, result.Value.Year);
        Assert.Equal(1, result.Value.Month);
        Assert.Equal(2, result.Value.Day);
    }

    [Fact]
    public void Read_OutOfRangeUnixEpoch_ReturnsNullViaFallback()
    {
        var result = DeserializeDate("{" + "\"value\":" + long.MaxValue + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_NumberThatCannotBeInt64_ReturnsNull()
    {
        var result = DeserializeDate("{" + "\"value\":1.5" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_NumberZeroUnixEpoch_ReturnsUtcUnixEpochStart()
    {
        var result = DeserializeDate("{" + "\"value\":0" + "}");

        Assert.NotNull(result);
        Assert.Equal(DateTimeOffset.FromUnixTimeSeconds(0).UtcDateTime, result.Value);
    }

    [Fact]
    public void Read_MinDateBoundary_ReturnsMinDateTime()
    {
        // Tests parsing of minimum representable date
        var result = DeserializeDate("{\n" + "\"value\":\"0001-01-01T00:00:00Z\"\n" + "}");

        Assert.NotNull(result);
        Assert.Equal(DateTime.SpecifyKind(DateTime.MinValue, DateTimeKind.Utc), result);
    }

    [Fact]
    public void Read_MaxDateBoundary_ReturnsMaxDateTime()
    {
        // Tests parsing of maximum representable date
        var result = DeserializeDate("{\n" + "\"value\":\"9999-12-31T23:59:59Z\"\n" + "}");

        Assert.NotNull(result);
        // Just verify it's a valid DateTime with correct year/month/day
        Assert.Equal(9999, result.Value.Year);
        Assert.Equal(12, result.Value.Month);
        Assert.Equal(31, result.Value.Day);
    }

    [Fact]
    public void Read_LeapYearDate_ReturnsParsedDateTime()
    {
        // Tests parsing of leap year date (Feb 29)
        var result = DeserializeDate("{\n" + "\"value\":\"2024-02-29T12:00:00Z\"\n" + "}");

        Assert.NotNull(result);
        Assert.Equal(29, result.Value.Day);
    }

    [Fact]
    public void Read_InvalidLeapYearDate_ReturnsNull()
    {
        // Tests rejection of Feb 29 in non-leap years
        var result = DeserializeDate("{\n" + "\"value\":\"2023-02-29T12:00:00Z\"\n" + "}");

        Assert.Null(result);
    }

    [Fact]
    public void Read_PartialDateString_ParsesAsDate()
    {
        // DateTime converter is lenient and parses "YYYY-MM" as first day of month
        var result = DeserializeDate("{\n" + "\"value\":\"2025-01\"\n" + "}");

        // Converter accepts this and fills in missing components
        Assert.NotNull(result);
        Assert.Equal(2025, result.Value.Year);
        Assert.Equal(1, result.Value.Month);
    }

    [Fact]
    public void Read_MalformedDateString_MayParsePartially()
    {
        // DateTime converter is lenient with some formats; test the ones it definitely rejects
        var strictlyInvalidCases = new[]
        {
            "not-a-date",
            "abc-def-ghi",
            "2025-13-01",  // Invalid month (>12)
        };

        foreach (var invalid in strictlyInvalidCases)
        {
            var result = DeserializeDate("{\n" + "\"value\":\"" + invalid + "\"\n" + "}");
            Assert.Null(result);
        }
    }

    [Fact]
    public void Read_InvalidUtf8ReaderState_ReturnsNullFromCatchPath()
    {
        var converter = new DateTimeNullableJsonConverter();
        var malformedBytes = new byte[] { (byte)'x' };
        var reader = new Utf8JsonReader(malformedBytes);

        var result = converter.Read(ref reader, typeof(DateTime?), new JsonSerializerOptions());

        Assert.Null(result);
    }

    [Fact]
    public void DebuggerLogCore_WhenDebuggerNotAttached_WritesDebugOnly()
    {
        var writeCalls = 0;
        var debuggerLogCalls = 0;

        DateTimeNullableJsonConverter.DebuggerLogCore(
            new InvalidOperationException("boom"),
            isDebuggerAttached: () => false,
            debugWriteLine: _ => writeCalls++,
            debuggerLog: (_, _, _) => debuggerLogCalls++);

        Assert.Equal(1, writeCalls);
        Assert.Equal(0, debuggerLogCalls);
    }

    [Fact]
    public void DebuggerLogCore_WhenDebuggerAttached_WritesDebugAndDebuggerLog()
    {
        var writeCalls = 0;
        var debuggerLogCalls = 0;

        DateTimeNullableJsonConverter.DebuggerLogCore(
            new InvalidOperationException("boom"),
            isDebuggerAttached: () => true,
            debugWriteLine: _ => writeCalls++,
            debuggerLog: (_, category, message) =>
            {
                debuggerLogCalls++;
                Assert.Equal("UndercutAnalyser", category);
                Assert.Contains("InvalidOperationException", message);
            });

        Assert.Equal(1, writeCalls);
        Assert.Equal(1, debuggerLogCalls);
    }

    [Fact]
    public void DebuggerLogCore_SwallowsSinkExceptions()
    {
        DateTimeNullableJsonConverter.DebuggerLogCore(
            new InvalidOperationException("boom"),
            isDebuggerAttached: () => true,
            debugWriteLine: _ => throw new Exception("debug sink fail"),
            debuggerLog: (_, _, _) => throw new Exception("debugger sink fail"));
    }

    [Fact]
    public void Read_DateTimeWithTimezone_ParsesButKindMayVary()
    {
        // DateTime converter parses timezone but kind depends on converter implementation
        var result = DeserializeDate("{\n" + "\"value\":\"2025-01-02T03:04:05+02:00\"\n" + "}");

        Assert.NotNull(result);
        // Just verify it parsed; the kind is converter-specific
        Assert.Equal(2025, result.Value.Year);
        Assert.Equal(1, result.Value.Month);
        Assert.Equal(2, result.Value.Day);
    }

    #endregion

    #region Write behavior
    // These tests exist to ensure serialization remains round-trippable and stable for
    // API diagnostics and persisted snapshots.

    [Fact]
    public void Write_NullValue_WritesJsonNull()
    {
        var json = SerializeDate(null);

        Assert.Equal("{\"value\":null}", json);
    }

    [Fact]
    public void Write_DateTime_WritesRoundTripIsoString()
    {
        var dt = new DateTime(2025, 6, 1, 12, 30, 45, DateTimeKind.Utc);

        var json = SerializeDate(dt);

        Assert.Equal("{\"value\":\"2025-06-01T12:30:45.0000000Z\"}", json);
    }

    [Fact]
    public void Write_MinDateTime_WritesCorrectlyFormatted()
    {
        // Tests serialization of minimum datetime
        var dt = DateTime.SpecifyKind(DateTime.MinValue, DateTimeKind.Utc);

        var json = SerializeDate(dt);

        Assert.Contains("0001-01-01", json);
        Assert.DoesNotContain("null", json);
    }

    [Fact]
    public void Write_MaxDateTime_WritesCorrectlyFormatted()
    {
        // Tests serialization of maximum datetime
        var dt = DateTime.SpecifyKind(DateTime.MaxValue, DateTimeKind.Utc);

        var json = SerializeDate(dt);

        Assert.Contains("9999-12-31", json);
        Assert.DoesNotContain("null", json);
    }

    #endregion

    private static DateTime? DeserializeDate(string json)
    {
        var wrapper = JsonSerializer.Deserialize<DateWrapper>(json, CreateOptions());
        return wrapper?.Value;
    }

    private static string SerializeDate(DateTime? value)
    {
        var wrapper = new DateWrapper { Value = value };
        return JsonSerializer.Serialize(wrapper, CreateOptions());
    }

    private static JsonSerializerOptions CreateOptions()
    {
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };
        options.Converters.Add(new DateTimeNullableJsonConverter());
        return options;
    }

    private sealed class DateWrapper
    {
        public DateTime? Value { get; init; }
    }
}
